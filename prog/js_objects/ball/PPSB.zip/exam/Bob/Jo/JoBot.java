public class JoBot extends Jo
{
    private boolean alive;

    public JoBot(String name)
    {
        super(name);
        alive = true;
    }

    public void setAlive(){
        alive = true;
    }
    
    public void setAlive(boolean alive){
        this.alive = alive;
    }
    public String toString()
    {
        return super.toString()  + " Alive: " + alive;
    }
}
