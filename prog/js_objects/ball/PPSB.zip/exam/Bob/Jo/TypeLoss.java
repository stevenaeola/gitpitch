
public class TypeLoss
{
   public static void main(String[] args){
       Jo j1 = new Jo("Joanna");
       JoBot j2 = new JoBot("Josephine");
       Jo j = j2;
       //JoBot j = (JoBot) j2; // this version works
       j2.setAlive(); // works fine
       j.setAlive(); // fails without type cast despite j==j2 due to type loss
    }
}
